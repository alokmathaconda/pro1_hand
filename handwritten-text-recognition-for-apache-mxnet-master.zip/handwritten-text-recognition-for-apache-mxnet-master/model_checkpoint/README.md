# Intermediary Model Checkpoints
